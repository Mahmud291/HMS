<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/footer.css">
  </head>
  <body>
    <footer>
      <div class="ft">
      <p> © 2046 Bristy,Jawtaz & nishat. All Rights Reserved. </p>
    </div>
    </footer>
  </body>
</html>
